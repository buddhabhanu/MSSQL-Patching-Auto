﻿$filename1="C:\tmp\logs\SQL_validation_Output.txt"
If(Test-Path $filename1)
{
Clear-Content -path "C:\tmp\logs\SQL_validation_Output.txt"
Clear-Content -path "C:\tmp\logs\Entire_list_Output.txt"

}

FOREACH($server in GC "C:\tmp\ServerList.txt")
 {
	$sqlstatment=invoke-expression -Command "&'C:\tmp\SQL_Patch_validation1.ps1' -ComputerName $server "  
$sqlstatment
$SQLlog = $sqlstatment | out-file -Filepath C:\tmp\logs\Entire_list_Output.txt -Append
 $sqllog
 }
 write-host "Please verify the output for the details" -ForegroundColor Green
 write-host "Location: C:\tmp\logs\SQL_validation_Output.txt " -ForegroundColor Yellow
 write-host "Location: C:\tmp\logs\Entire_list_Output.txt " -ForegroundColor Yellow
 
