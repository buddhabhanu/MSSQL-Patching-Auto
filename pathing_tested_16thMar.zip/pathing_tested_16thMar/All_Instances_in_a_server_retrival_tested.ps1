﻿$SERVER='WIN-CMN9PDTCQ46'
function getSQLInstanceOnServer ([string]$SERVER) {
$services = Get-Service -Computer $SERVER
$services = $services | ? DisplayName -like "SQL Server (*)"
try {
$instances = $services.Name | ForEach-Object {($_).Replace("MSSQL`$","$env:COMPUTERNAME"+'\')} 
$instances = $instances | ForEach-Object {($_).Replace("MSSQLSERVER","$env:COMPUTERNAME")} 
}catch{
# if no instances are found return
return -1
}

return $instances
}
$server1=getSQLInstanceOnServer $SERVER
$server1

